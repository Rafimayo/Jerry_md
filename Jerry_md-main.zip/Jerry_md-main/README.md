
### <br>     🇲 🇷 .🇯 🇪 🇷 🇷 🇾 
 <p align="center">
  <a href="#"><img src="http://readme-typing-svg.herokuapp.com?color=00008B&center=true&vCenter=true&multiline=false&lines=`LEGEND+-+JERRY+-+MD+WHATSAPP+BOT`" alt="">
<br>
<a href="https://git.io/typing-svg"><img src="https://readme-typing-svg.demolab.com?font=Black+Ops+One&size=50&pause=1000&color=1BAFBAFF&center=true&width=810&height=100&lines=+LEGEND-JERRY-MD;IS+THE+UPDATE+VERSION-MD;BEST+MULTI+DEVICE+BOT;CREATED+BY+MR.JERRY" alt="Typing SVG" /></a>



 
<a><img src='https://i.imgur.com/LyHic3i.gif'/></a>
<a><img src='https://i.imgur.com/LyHic3i.gif'/></a>
<br>

![Image](https://github.com/user-attachments/assets/9e6151f1-f1ae-454f-9f9f-32499ac3eb36)

`❀❀❀❀❀❀❀❀❀❀❀❀❀❀❀❀❀❀❀❀❀❀`
<br>
              👀
### <br>  ❖ LEGEND-JERRY-MD ❖
🔰 **`THE WORLD BEST WHATSAPP BOT CREATED BY ❉্᭄͜͡ *🅐︎ᴡᴀɪs 🅙︎ᴀɴɪɪ* ❉্᭄͜͡// LEGEND🥷JERRY.`** 🔰

<br>

`❀❀❀❀❀❀❀❀❀❀❀❀❀❀❀❀❀❀❀❀❀❀`
*Ξ ⤹³ 🧸🫀🥂♥️ ⃙̊-*

*🙂"میــــؔـــری مـــؔــاں میــــؔــری جنّـــؔــت". . 

<br>

`⚛⚛⚛⚛⚛⚛⚛⚛⚛⚛⚛⚛⚛⚛⚛⚛⚛⚛⚛⚛⚛⚛⚛⚛⚛⚛⚛`

<br>

### <br> ❖ FOR SUPPORT ❖

**`➩ HII DEARS FRIENDS IF YOU WANT ANY HELP SO YOU CAN CONTACT↘︎ WITH ME WIA WHATSAPP ITS ME LEGEND✠JERRY࿐➺`**
<p align="center">
  <a href="https://wa.me/+923126460870?text=*ʜᴇʟʟᴏ+ᴍʀ.ᴊᴇʀʀʏ--+ʜᴏᴡ+ᴀʀᴇ+ʏᴏᴜ+ɪ+ɴᴇᴇᴅ+ʜᴇʟᴘ!.+ɪ+ᴍᴇssᴀɢᴇᴅ+ʏᴏᴜ+ғʀᴏᴍ+ʟᴇɢᴇɴᴅ-ᴊᴇʀʀʏ-ᴍᴅ+ʀᴇᴘᴏ!!*" target="_blank">
    <img alt="whatsapp" src="https://img.shields.io/badge/ Whatsapp -25D366?style=for-the-badge&logo=whatsapp&logoColor=white" />
    <br>

<a href="https://whatsapp.com/channel/0029VbAguYV2ZjCetGnmwH0x"><img src="https://img.shields.io/badge/%F0%9F%8E%89%20ᴊᴏɪɴ%20ᴏᴜʀ%20ᴡʜᴀᴛsᴀᴘᴘ%20ᴄʜᴀɴɴᴇʟ-red" alt="🔰 ᴊᴏɪɴ ᴍʏ ᴡʜᴀᴛsᴀᴘᴘ ɢʀᴏᴜᴘ ғᴏʀ ᴜᴘᴅᴀᴛᴇ 🔰" width="300"></a>


<br>

<a href="https://www.youtube.com/@Mr-jerry-md"><img src="https://img.shields.io/badge/%F0%9F%8E%89%20ᴊᴏɪɴ%20ᴏᴜʀ%20ʏᴏᴜᴛᴜʙᴇ%20ᴄʜᴀɴɴᴇʟ-blue" alt="🔰 ᴊᴏɪɴ ᴍʏ ʏᴏᴜᴛᴜʙᴇ ғᴏʀ ᴜᴘᴅᴀᴛᴇ 🔰" width="300"></a>


<br>


### <br>    ❖ SESSION_ID ❖

`✠ IF YOU DON'T HAVE YOUR SESSION_ID SO U CAN GET IT CLICK ON SESSION_ID BUTTON AND PASTE YOUR NUMBER With COUNTRY CODE EXAMPLE:+92325*****THEN YOU CAN GET YOUR SESSION_ID ✠`

<br>


> **1. PAIR CODE SESSION ID**

----------

<p align="center">
<a href='https://jerrymdpair-ca50be6b3a58.herokuapp.com/' target="_blank">
  <img alt='Pairing Code' src='https://img.shields.io/badge/Get%20Session%20id-FF0000?style=for-the-badge&logo=opencv&logoColor=black'/>
</a>

> **2. PAIR CODE SESSION ID**

----------

<p align="center">
<a href='https://jerrymdpair-ca50be6b3a58.herokuapp.com/' target="_blank">
  <img alt='Pairing Code' src='https://img.shields.io/badge/Get%20Session%20id-0000FF?style=for-the-badge&logo=opencv&logoColor=black'/>
</a>
 
--------
 

<br>

***JERRY-MD BOT REPO***

 ### <h2 align="">❖ JERRY-MD
 DEPLOYMENT OPTIONS ❖</h2>

---

<a><img src='https://i.imgur.com/LyHic3i.gif'/></a>

-------

  <table>
    <tr>
      <td><a href="https://dashboard.heroku.com/new?template=https://github.com/Rafimayo/Jerry_md" target="_blank"><img src="https://img.shields.io/badge/Heroku-430098?style=for-the-badge&logo=heroku&logoColor=white&labelColor=000000&color=00ffff"/></a></td>
      <td><a href="https://talkdrove.com" target="_blank"><img src="https://img.shields.io/badge/TalkDrove-6971FF?style=for-the-badge&logo=github&logoColor=white&labelColor=000000"/></a></td>
    </tr>
    <tr>
      <td><a href="https://app.koyeb.com/services/deploy?type=git&repository=DARKSILENCE04/DARK-SILENCE-MD" target="_blank"><img src="https://img.shields.io/badge/Koyeb-FF009D?style=for-the-badge&logo=koyeb&logoColor=white&labelColor=000000"/></a></td>
      <td><a href="https://railway.app/new" target="_blank"><img src="https://img.shields.io/badge/Railway-FF8700?style=for-the-badge&logo=railway&logoColor=white&labelColor=000000"/></a></td>
    </tr>
    <tr>
      <td><a href="https://dashboard.render.com/web/new" target="_blank"><img src="https://img.shields.io/badge/Render-000000?style=for-the-badge&logo=render&logoColor=white&labelColor=000000&color=00ffaa"/></a></td>
      <td><a href="https://app.netlify.com/" target="_blank"><img src="https://img.shields.io/badge/Netlify-CC00FF?style=for-the-badge&logo=huggingface&logoColor=white&labelColor=000000"/></a></td>
    </tr>
  </table>
</div>

<table align="center">
  <tr>
    <td>
      <a href="https://whatsapp.com/channel/0029VaHO5B0G3R3cWkZN970s/3616" target="_blank">
        <img alt="View Workflow Codes" src="https://img.shields.io/badge/View-Workflow%20Codes-FF0076?style=for-the-badge&logo=githubactions&logoColor=white"/>
      </a>
    </td>
  </tr>
</table>  

<div align="center">
  <img src="https://github.com/DARKSILENCE04/DARK-SILENCE-MD/blob/main/assets/techwave.gif?raw=true" width="100%"/>
</div>

      

<br>



<a><img src='https://i.imgur.com/LyHic3i.gif'/></a>
<a><img src='https://i.imgur.com/LyHic3i.gif'/></a>


<br>

`⚛⚛⚛⚛⚛⚛⚛⚛⚛⚛⚛⚛⚛⚛⚛⚛⚛⚛⚛⚛⚛⚛⚛⚛⚛⚛⚛`

<br>

<a><img src='https://i.imgur.com/LyHic3i.gif'/></a>
<a><img src='https://i.imgur.com/LyHic3i.gif'/></a>

<br>

![license](https://img.shields.io/github/license/Rafimayo/Jerry-md?color=green&label=License&style=plastic)

