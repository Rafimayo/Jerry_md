#!/bin/sh
npm install
npm run start
